﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            #region Static filling Contact array
            //Contact[] phoneBook = new Contact[3];

            //phoneBook[0] = new Contact();
            //phoneBook[1] = new Contact();
            //phoneBook[2] = new Contact();

            //phoneBook[0].Phone = "+994 55 555 5555";
            //phoneBook[0].Name = "Nadir";

            //phoneBook[1].Phone = "+994 51 505 5555";
            //phoneBook[1].Name = "Zakir";

            //phoneBook[2].Phone = "+994 55 500 2255";
            //phoneBook[2].Name = "Elsad";

            //for (int i = 0; i < phoneBook.Length; i++)
            //{
            //    Contact item = phoneBook[i];
            //    Console.WriteLine($"{item.Name} - {item.Phone}");
            //}
            #endregion

            Console.Write("What length do you need to create contact list:");
            int contactCount = int.Parse(Console.ReadLine());

            Contact[] phoneBook = new Contact[contactCount];

            for (int i = 0; i < contactCount; i++)
            {
                phoneBook[i] = new Contact();

                Console.Write($"Input {i + 1}th Contact name: ");
                string name = Console.ReadLine();

                Console.Write($"Input {i + 1}th Contact phone number: ");
                string phone = Console.ReadLine();

                phoneBook[i].Name = name;
                phoneBook[i].Phone = phone;
            }

            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Select 1 for searching by name or 2 for searching by phone number:");

            int keyNumber = int.Parse(Console.ReadLine());
            if (keyNumber == 1)
            {
                Console.Write("\nPlease, input search name: ");
                string searchName = Console.ReadLine();

                int counter = 0;
                for (int i = 0; i < contactCount; i++)
                {
                    if(phoneBook[i].Name.ToLower().Contains(searchName.ToLower()))
                    {
                        counter++;
                        Console.WriteLine($"Found: {phoneBook[i].Name} - {phoneBook[i].Phone}");
                    }
                }

                if(counter == 0) Console.WriteLine("404 - Not found");

            }
            else if (keyNumber == 2)
            {
                Console.Write("\nPlease, input search phone number: ");
                string searchNumber = Console.ReadLine();
                string clearedSearchNumber = searchNumber.Replace(" ", "").Replace("-", "");

                int counter = 0;
                for (int i = 0; i < contactCount; i++)
                {
                    string clearedContactNumber = phoneBook[i].Phone.Replace(" ", "").Replace("-", "");

                    if(clearedContactNumber == clearedSearchNumber)
                    {
                        counter++;
                        Console.WriteLine($"Found: {phoneBook[i].Name} - {phoneBook[i].Phone}");
                    }
                }
                if (counter == 0) Console.WriteLine("404 - Not found");
            }
            else
            {
                Console.WriteLine("You selected smt wrong");
            }


        }
    }

    class Contact
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (value.Length < 2)
                {
                    throw new ArgumentException("Contact name can not be less than 2 characters");
                }

                _name = value;
            }
        }

        private string _phone;
        public string Phone
        {
            get { return _phone; }
            set
            {
                Regex regex = new Regex(@"(\+994) *(50|51|55|70|77)-? *[2-9]{1}\d{2}-? *-?\d{2}-? *\d{2}");

                if (!regex.IsMatch(value))
                {
                    throw new ArgumentException("Phone number is not in a correct format");
                }

                _phone = value;
            }
        }

    }
}
