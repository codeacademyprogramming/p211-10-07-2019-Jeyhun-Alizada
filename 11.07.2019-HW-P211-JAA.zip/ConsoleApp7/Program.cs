﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("How many you want will be add Contact: ");
            string myStroge = Console.ReadLine();
            PhoneBook[] contacts = new PhoneBook[int.Parse(myStroge)];
            for (int i = 0; i < contacts.Length; i++)
            {
                Console.Write($"Input {i + 1}-th contact name: ");
                string myName = Console.ReadLine();
                foreach (PhoneBook item in contacts)
                {
                    if (item != null && item.Name == myName)
                    {
                        Console.WriteLine("Bu ad mövcuddur, başqa bir ad əlavə edin.");
                    }
                    else
                    {
                        contacts[i] = new PhoneBook
                        {
                            Name = myName
                        };
                    }
                }
                Console.Write($"Input {i + 1}-th contact number: ");
                string myNumber = Console.ReadLine();
                foreach (PhoneBook item in contacts)
                {
                    if (item != null && item.Number == myNumber)
                    {
                        Console.WriteLine($"Bu nömrə mövcuddur, {item.Name}-ə məxsusdur.");
                    }
                    else
                    {
                        contacts[i] = new PhoneBook
                        {
                            Number = myNumber
                        };
                    }
                }

            }
            for (int i = 0; i < contacts.Length; i++)
            {
                Console.WriteLine(contacts[i].Name);
                Console.WriteLine(contacts[i].Number);
            }

            Console.Write("Input for search: ");
            string mySearch = Console.ReadLine();
            for (int i = 0; i < contacts.Length; i++)
            {
                if (contacts[i].Name == mySearch)
                {
                    Console.WriteLine(contacts[i].Number);
                }
                else
                {
                    Console.WriteLine(mySearch + "-e uygun netice tapilmadi.");
                }
            }
            Console.ReadKey();
        }
    }
    public class PhoneBook
    {
        private string _number;
        public string Number
        {
            get { return _number; }

            set
            {
                Regex regex = new Regex(@"(\+994) (50|51|55|70|77)-? *[2-9]{1}\d{2}-? *-?\d{4}");
                if (regex.IsMatch(value))
                {
                    _number = value;
                }
                else
                {
                    throw new ArgumentException("Daxil etdiyiniz nomre formata uygun deyil.");
                }
            }
        }
        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (value.Trim().Length <= 2)
                {
                    throw new ArgumentException("Ad 2 herfden az ola bilmez.");
                }

                _name = value.Trim();
            }
        }
    }
}



